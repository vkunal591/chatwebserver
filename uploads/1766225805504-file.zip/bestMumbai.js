// import axios from "axios";
// import * as cheerio from "cheerio";
// import { URLSearchParams } from "url";

// /***************************************************
//  * CONSTANTS
//  ***************************************************/
// const BASE = "https://www.bestundertaking.net/";
// const DEBUG = true;
// const log = (...x) => DEBUG && console.log(...x);

// /***************************************************
//  * MERGE COOKIES
//  ***************************************************/
// function mergeCookies(oldCookies = "", newSetCookies = []) {
//     const jar = {};

//     oldCookies.split(";").forEach(c => {
//         const [k, v] = c.trim().split("=");
//         if (k) jar[k] = v;
//     });

//     newSetCookies.forEach(sc => {
//         const [pair] = sc.split(";");
//         const [k, v] = pair.split("=");
//         jar[k.trim()] = v;
//     });

//     return Object.entries(jar)
//         .map(([k, v]) => `${k}=${v}`)
//         .join("; ");
// }

// /***************************************************
//  * EXTRACT FORM INPUT FIELDS
//  ***************************************************/
// function extractForm(html) {
//     const $ = cheerio.load(html);
//     const form = {};

//     $("input[name]").each((i, el) => {
//         form[$(el).attr("name")] = $(el).val() || "";
//     });

//     return form;
// }

// /***************************************************
//  * BASE REQUEST WRAPPER
//  ***************************************************/
// async function request(method, url, data = null, cookies = "", headersExtra = {}) {
//     console.log(method, url, data, cookies,)
//     const res = await axios({
//         method,
//         url,
//         data,
//         maxRedirects: 0,
//         validateStatus: s => s < 400,
//         headers: {
//             "User-Agent": "Mozilla/5.0",
//             "Content-Type": "application/x-www-form-urlencoded",
//             Cookie: cookies,
//             Referer: BASE,
//             Origin: BASE,
//             ...headersExtra
//         }
//     });

//     const newCookies = mergeCookies(cookies, res.headers["set-cookie"] ?? []);
//     return { res, cookies: newCookies };
// }

// /***************************************************
//  * STEP 1: Load Initial Page
//  ***************************************************/
// async function step1_loadInitial() {
//     log("\n================ STEP 1 — Load Initial Page ================");

//     const { res, cookies } = await request("GET", BASE);

//     return {
//         html: res.data,
//         cookies,
//         form: extractForm(res.data)
//     };
// }

// /***************************************************
//  * STEP 2: Submit Show Bill
//  ***************************************************/
// async function step2_showBill(form, cookies, accountNo) {
//     log("\n================ STEP 2 — Submit Show Bill ================");

//     const postForm = {
//         "__EVENTTARGET": "",
//         "__EVENTARGUMENT": "",
//         "__LASTFOCUS": "",
//         "__VIEWSTATE": form["__VIEWSTATE"],
//         "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],

//         "ctl00$ContentPlaceHolder1$txtaccno": accountNo,
//         "ctl00$ContentPlaceHolder1$chkhuman": "on",
//         "ctl00$ContentPlaceHolder1$btnquickpay": "Pay Online",

//         "ctl00$ContentPlaceHolder1$txtsigninaccno": "",
//         "ctl00$ContentPlaceHolder1$txtPwdReg": ""
//     };

//     const { res, cookies: newCookies } = await request(
//         "POST",
//         BASE,
//         new URLSearchParams(postForm).toString(),
//         cookies
//     );

//     return {
//         html: res.data,
//         cookies: newCookies,
//         form: extractForm(res.data)
//     };
// }

// /***************************************************
//  * STEP 3: Extract Amount
//  ***************************************************/
// function step3_extractAmount(form) {
//     log("\n================ STEP 3 — Extract Bill Amount ================");

//     const amount = form["ctl00$ContentPlaceHolder1$txtpayblepayment"];
//     if (!amount) {
//         throw new Error("❌ Bill amount not found.");
//     }

//     log("Bill Amount:", amount);
//     return amount;
// }

// /***************************************************
//  * STEP 4: Submit Payment Request
//  ***************************************************/
// async function step4_submitPayment(form, cookies, amount) {
//     log("\n================ STEP 4 — Submit Payment Request ================");

//     const postForm = {
//         "__EVENTTARGET": "",
//         "__EVENTARGUMENT": "",
//         "__VIEWSTATE": form["__VIEWSTATE"],
//         "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],

//         "ctl00$ContentPlaceHolder1$txtpayblepayment": amount > 0 ? amount : 100,
//         "ctl00$ContentPlaceHolder1$btnpay": "Pay",

//         "ctl00$ContentPlaceHolder1$txtsigninaccno": "",
//         "ctl00$ContentPlaceHolder1$txtPwdReg": ""
//     };

//     const { res, cookies: newCookies } = await request(
//         "POST",
//         BASE,
//         new URLSearchParams(postForm).toString(),
//         cookies
//     );

//     const redirectURL = res.headers.location || "";

//     return {
//         redirectURL,
//         cookies: newCookies
//     };
// }

// /***************************************************
//  * MAIN — SYNCHRONOUS FLOW
//  ***************************************************/
// async function main() {
//     try {
//         const ACCOUNT_NO = "526113020";

//         // STEP 1
//         const s1 = await step1_loadInitial();

//         // STEP 2
//         const s2 = await step2_showBill(s1.form, s1.cookies, ACCOUNT_NO);

//         // STEP 3
//         const amount = step3_extractAmount(s2.form);

//         // STEP 4
//         const s4 = await step4_submitPayment(s2.form, s2.cookies, amount);

//         console.log("\n================ FINAL RESULT ================");
//         console.log("➡ Redirect to Payment Gateway:", s4.redirectURL);
//         console.log("➡ Cookies:", s4.cookies);

//         if (!s4.redirectURL) {
//             console.log("❌ Payment failed. VIEWSTATE issue or server changed.");
//         }

//         return s4; // return final API output

//     } catch (err) {
//         console.error("ERROR:", err.message);
//     }
// }

// main();




























// import axios from "axios";
// import * as cheerio from "cheerio";
// import { URLSearchParams } from "url";
// import puppeteer from "puppeteer";

// /***************************************************
//  * CONSTANTS
//  ***************************************************/
// const BASE = "https://www.bestundertaking.net/";
// const DEBUG = true;
// const log = (...x) => DEBUG && console.log(...x);

// /***************************************************
//  * MERGE COOKIES
//  ***************************************************/
// function mergeCookies(oldCookies = "", newCookies = []) {
//     const jar = {};

//     oldCookies.split(";").forEach(c => {
//         const [k, v] = c.trim().split("=");
//         if (k) jar[k] = v;
//     });

//     newCookies.forEach(sc => {
//         const [pair] = sc.split(";");
//         const [k, v] = pair.trim().split("=");
//         jar[k] = v;
//     });

//     return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join("; ");
// }

// /***************************************************
//  * FORM EXTRACTOR
//  ***************************************************/
// function extractForm(html) {
//     const $ = cheerio.load(html);
//     const form = {};

//     $("input[name]").each((_, el) => {
//         form[$(el).attr("name")] = $(el).val() || "";
//     });

//     return form;
// }

// /***************************************************
//  * REQUEST WRAPPER
//  ***************************************************/
// async function request(method, url, data = null, cookies = "", headersExtra = {}) {
//     console.log("\nREQ →", method, url);

//     const res = await axios({
//         method,
//         url,
//         data,
//         maxRedirects: 0,
//         validateStatus: s => s < 400,
//         headers: {
//             "User-Agent": "Mozilla/5.0",
//             "Content-Type": "application/x-www-form-urlencoded",
//             Cookie: cookies,
//             Referer: BASE,
//             Origin: BASE,
//             ...headersExtra
//         }
//     });

//     const newCookies = mergeCookies(cookies, res.headers["set-cookie"] ?? []);
//     return { res, cookies: newCookies };
// }

// /***************************************************
//  * STEP 1 — Load Homepage
//  ***************************************************/
// async function step1_loadInitial() {
//     log("STEP 1 — Load Initial Page");

//     const { res, cookies } = await request("GET", BASE);
//     return {
//         html: res.data,
//         cookies,
//         form: extractForm(res.data)
//     };
// }

// /***************************************************
//  * STEP 2 — Submit Show Bill
//  ***************************************************/
// async function step2_showBill(form, cookies, accNo) {
//     log("STEP 2 — Submit Show Bill");

//     const post = {
//         "__EVENTTARGET": "",
//         "__EVENTARGUMENT": "",
//         "__LASTFOCUS": "",
//         "__VIEWSTATE": form["__VIEWSTATE"],
//         "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],
//         "ctl00$ContentPlaceHolder1$txtaccno": accNo,
//         "ctl00$ContentPlaceHolder1$chkhuman": "on",
//         "ctl00$ContentPlaceHolder1$btnquickpay": "Pay Online",
//         "ctl00$ContentPlaceHolder1$txtsigninaccno": "",
//         "ctl00$ContentPlaceHolder1$txtPwdReg": ""
//     };

//     const { res, cookies: newCookies } = await request(
//         "POST",
//         BASE,
//         new URLSearchParams(post).toString(),
//         cookies
//     );

//     return {
//         html: res.data,
//         cookies: newCookies,
//         form: extractForm(res.data)
//     };
// }

// /***************************************************
//  * STEP 3 — Extract Amount
//  ***************************************************/
// function step3_extractAmount(form) {
//     log("STEP 3 — Extract Amount");

//     const amount = form["ctl00$ContentPlaceHolder1$txtpayblepayment"];
//     if (!amount) throw new Error("Amount missing!");

//     console.log("Bill Amount:", amount);
//     return amount;
// }

// /***************************************************
//  * STEP 4 — Submit Payment Request
//  ***************************************************/
// async function step4_submitPayment(form, cookies, amount) {
//     log("STEP 4 — Submit Payment Request");

//     const post = {
//         "__EVENTTARGET": "",
//         "__EVENTARGUMENT": "",
//         "__VIEWSTATE": form["__VIEWSTATE"],
//         "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],
//         "ctl00$ContentPlaceHolder1$txtpayblepayment": amount > 0 ? amount : 100,
//         "ctl00$ContentPlaceHolder1$btnpay": "Pay",
//         "ctl00$ContentPlaceHolder1$txtsigninaccno": "",
//         "ctl00$ContentPlaceHolder1$txtPwdReg": ""
//     };

//     const { res, cookies: newCookies } = await request(
//         "POST",
//         BASE,
//         new URLSearchParams(post).toString(),
//         cookies
//     );

//     return {
//         redirectURL: res.headers.location,
//         cookies: newCookies
//     };
// }

// /***************************************************
//  * STEP 5 — AGREE PAGE (CURL #1)
//  ***************************************************/
// async function step5_submitAgree(cookies) {
//     log("STEP 5 — Submit AGREE (curl #1)");

//     const url = BASE + "QuickPayOnline.aspx";

//     const postPayload =
//         "__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&" +
//         "__VIEWSTATE=&__VIEWSTATEGENERATOR=11AE8DBA&__EVENTVALIDATION=&" +
//         "ctl00%24ContentPlaceHolder1%24hdnField=1&" +
//         "ctl00%24ContentPlaceHolder1%24hdnPayMode=1&" +
//         "ctl00%24ContentPlaceHolder1%24chkagree=on&" +
//         "ctl00%24ContentPlaceHolder1%24btnagree=Agree";

//     const { res, cookies: newCookies } = await request(
//         "POST",
//         url,
//         postPayload,
//         cookies,
//         { Referer: url }
//     );

//     return {
//         redirectURL: res.headers.location,
//         cookies: newCookies
//     };
// }

// /***************************************************
//  * STEP 6 — OPEN PayUTJSB.aspx IN BROWSER WITH SESSION COOKIES
//  ***************************************************/
// async function step6_openInBrowserWithPuppeteer(cookiesString) {
//     console.log("\nSTEP 6 — Puppeteer Opening PayUTJSB.aspx with Correct Cookies");

//     const browser = await puppeteer.launch({
//         headless: false,
//         defaultViewport: null
//     });

//     const page = await browser.newPage();

//     const cookieArray = cookiesString.split(";").map(c => {
//         const [name, value] = c.trim().split("=");
//         return {
//             name,
//             value,
//             domain: "www.bestundertaking.net",
//             path: "/"
//         };
//     });

//     await page.setCookie(...cookieArray);

//     console.log("➡ Cookies applied to browser:", cookieArray);

//     const url = BASE + "PayUTJSB.aspx";

//     await page.goto(url, { waitUntil: "networkidle2" });

//     console.log("➡ PayUTJSB.aspx OPENED IN BROWSER");
//     console.log("➡ PayU Auto-Submit Form Should Trigger…");

//     await page.waitForTimeout(9000);

//     return { browser, page };
// }

// /***************************************************
//  * MAIN FLOW
//  ***************************************************/
// async function main() {
//     try {
//         const ACCOUNT_NO = "526113020";

//         const s1 = await step1_loadInitial();
//         const s2 = await step2_showBill(s1.form, s1.cookies, ACCOUNT_NO);
//         const amount = step3_extractAmount(s2.form);
//         const s4 = await step4_submitPayment(s2.form, s2.cookies, amount);

//         const s5 = await step5_submitAgree(s4.cookies);

//         // STEP 6 — Open PayUTJSB.aspx in real browser
//         await step6_openInBrowserWithPuppeteer(s5.cookies);

//     } catch (err) {
//         console.error("ERROR:", err.message);
//     }
// }

// main();







import axios from "axios";
import * as cheerio from "cheerio";
import puppeteer from "puppeteer";
import { URLSearchParams } from "url";

/***************************************************
 * CONSTANTS
 ***************************************************/
const BASE = "https://www.bestundertaking.net/";
const DEBUG = true;
const log = (...x) => DEBUG && console.log(...x);

/***************************************************
 * MERGE COOKIES
 ***************************************************/
function mergeCookies(oldCookies = "", newSetCookies = []) {
    const jar = {};
    oldCookies.split(";").forEach(c => {
        const [k, v] = c.trim().split("=");
        if (k) jar[k] = v;
    });

    newSetCookies.forEach(sc => {
        const [pair] = sc.split(";");
        const [k, v] = pair.split("=");
        jar[k.trim()] = v;
    });

    return Object.entries(jar)
        .map(([k, v]) => `${k}=${v}`)
        .join("; ");
}

/***************************************************
 * EXTRACT FORM FIELDS
 ***************************************************/
function extractForm(html) {
    const $ = cheerio.load(html);
    const form = {};

    $("input[name]").each((i, el) => {
        form[$(el).attr("name")] = $(el).val() || "";
    });

    return form;
}

/***************************************************
 * REQUEST WRAPPER
 ***************************************************/
async function request(method, url, data = null, cookies = "", headersExtra = {}) {
    const res = await axios({
        method,
        url,
        data,
        maxRedirects: 0,
        validateStatus: s => s < 400,
        headers: {
            "User-Agent": "Mozilla/5.0",
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: cookies,
            Referer: BASE,
            Origin: BASE,
            ...headersExtra
        }
    });

    const newCookies = mergeCookies(cookies, res.headers["set-cookie"] ?? []);
    return { res, cookies: newCookies };
}

/***************************************************
 * STEP 1 — Load Initial Page
 ***************************************************/
async function step1_loadInitial() {
    log("STEP 1: Load Initial");

    const { res, cookies } = await request("GET", BASE);

    return {
        html: res.data,
        cookies,
        form: extractForm(res.data)
    };
}

/***************************************************
 * STEP 2 — Submit Show Bill
 ***************************************************/
async function step2_showBill(form, cookies, accountNo) {
    log("STEP 2: Show Bill");

    const postForm = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": form["__VIEWSTATE"],
        "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],
        "ctl00$ContentPlaceHolder1$txtaccno": accountNo,
        "ctl00$ContentPlaceHolder1$chkhuman": "on",
        "ctl00$ContentPlaceHolder1$btnquickpay": "Pay Online",
    };

    const { res, cookies: newCookies } = await request(
        "POST",
        BASE,
        new URLSearchParams(postForm).toString(),
        cookies
    );

    return {
        html: res.data,
        cookies: newCookies,
        form: extractForm(res.data)
    };
}

/***************************************************
 * STEP 3 — Extract Amount
 ***************************************************/
function step3_extractAmount(form) {
    const amount = form["ctl00$ContentPlaceHolder1$txtpayblepayment"];
    if (!amount) throw new Error("Bill amount not found");
    return amount;
}

/***************************************************
 * STEP 4 — Submit Payment Request
 ***************************************************/
async function step4_submitPayment(form, cookies, amount) {
    log("STEP 4: Submit Payment");

    const postForm = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": form["__VIEWSTATE"],
        "__VIEWSTATEGENERATOR": form["__VIEWSTATEGENERATOR"],
        "ctl00$ContentPlaceHolder1$txtpayblepayment": amount,
        "ctl00$ContentPlaceHolder1$btnpay": "Pay",
        "ctl00$ContentPlaceHolder1$txtsigninaccno": '',
        "ctl00$ContentPlaceHolder1$txtPwdReg": ""
    };
    console.log(postForm)

    const { res, cookies: newCookies } = await request(
        "POST",
        BASE,
        new URLSearchParams(postForm).toString(),
        cookies
    );

    return {
        redirectURL: res.headers.location || "",
        cookies: newCookies
    };
}

/***************************************************
 * STEP 5 — OPEN curl#5 IN PUPPETEER
 ***************************************************/
async function step5_openCurlInPuppeteer(sessionCookie) {
    console.log("\n========== STEP 5 — CURL POST INSIDE PUPPETEER ==========");

    const browser = await puppeteer.launch({
        headless: false,
        defaultViewport: null
    });

    const page = await browser.newPage();

    // 1. Set ASP.NET cookie
    await page.setCookie({
        name: "ASP.NET_SessionId",
        value: sessionCookie.split("=")[1],  // after =
        domain: "www.bestundertaking.net",
        path: "/"
    });

    // 2. Enable request interception
    await page.setRequestInterception(true);

    page.on("request", req => {
        if (req.url() === "https://www.bestundertaking.net/QuickPayOnline.aspx") {

            const postData = `__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=...LONG...&ctl00%24ContentPlaceHolder1%24btnagree=Agree`;

            req.continue({
                method: "POST",
                postData,
                headers: {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9",
                    "content-type": "application/x-www-form-urlencoded",
                    "origin": "https://www.bestundertaking.net",
                    "referer": "https://www.bestundertaking.net/QuickPayOnline.aspx",
                    "user-agent": "Mozilla/5.0",
                    ...req.headers()
                }
            });
        } else req.continue();
    });

    // 3. Trigger POST request
    await page.goto("https://www.bestundertaking.net/QuickPayOnline.aspx", {
        waitUntil: "networkidle2"
    });

    console.log("✔ CURL #5 SENT INSIDE PUPPETEER");
}

/***************************************************
 * MAIN — SYNC FLOW
 ***************************************************/
async function main() {
    const ACCOUNT = "526113020";

    const s1 = await step1_loadInitial();
    const s2 = await step2_showBill(s1.form, s1.cookies, ACCOUNT);
    const amount = step3_extractAmount(s2.form);
    const s4 = await step4_submitPayment(s2.form, s2.cookies, amount);

    console.log("\nRedirect from Step4:", s4.redirectURL);
    console.log("Cookies:", s4.cookies);

    // NOW OPEN STEP 5 (your curl)
    await step5_openCurlInPuppeteer(s4.cookies);
}

main();
