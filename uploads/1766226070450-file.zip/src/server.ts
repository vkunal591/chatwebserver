import "colors";
import { createServer, Server as HttpServer } from "http";
import { App } from "./app";
import { Env } from "./config/Env";
import { Database } from "./config/Database";
import { Logger } from "./config/Logger";
import { Socket } from "./config/Socket";


class Server {
  private server: HttpServer;

  constructor() {
    Logger.init();

    // ✅ Load environment variables
    Env.load();

    // ✅ Initialize Express app
    const app = new App();

    // ✅ Create HTTP server
    this.server = createServer(app.app);

    // ✅ Initialize Socket.IO
    new Socket(this.server);
  }

  public async start(): Promise<void> {
    try {
      await Database.connect();
      Logger.success("✅ Database connected");
      this.server.listen(Env.PORT, "0.0.0.0", () => {
        Logger.info(`🚀 Server running on port ${Env.PORT}`);
      });
    } catch (error: any) {
      Logger.fatal("❌ Server failed to start", error);
    }
  }
}

// ===== Global Error Handling =====
process.on("uncaughtException", (error: Error) => {
  Logger.exception(error);
});

process.on(
  "unhandledRejection",
  (reason: unknown) => {
    const error =
      reason instanceof Error
        ? reason
        : new Error(String(reason));

    Logger.exception(error);
  }
);

// 🚀 Start server
new Server().start();
