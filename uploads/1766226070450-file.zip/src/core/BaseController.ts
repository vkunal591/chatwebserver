import { Request, Response, NextFunction } from "express";
import { Document } from "mongoose";
import { BaseService } from "../core/BaseService";
import { errorResponse, successResponse } from "./ApiResponse";

export class BaseController<T extends Document> {
  protected service: BaseService<T>;

  constructor(service: BaseService<T>) {
    this.service = service;

    this.create = this.create.bind(this);
    this.getAll = this.getAll.bind(this);
    this.getById = this.getById.bind(this);
    this.update = this.update.bind(this);
    this.delete = this.delete.bind(this);
  }

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await this.service.create(req.body);
      successResponse(res, data, "Created successfully", 201);
    } catch (err) {
      next(err);
    }
  }

  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const skip = Number(req.query.skip) || 0;
      const limit = Number(req.query.limit) || 10;

      const data = await this.service.findAll({}, skip, limit);
      successResponse(res, data, "Fetched successfully");
    } catch (err) {
      next(err);
    }
  }

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await this.service.findById(req.params.id);
      if (!data) return errorResponse(res, "Not Found", 404);
      successResponse(res, data, "Fetched successfully");
    } catch (err) {
      next(err);
    }
  }

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await this.service.update(req.params.id, req.body);
      if (!data) return errorResponse(res, "Not Found", 404);
      successResponse(res, data, "Updated successfully");
    } catch (err) {
      next(err);
    }
  }

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await this.service.delete(req.params.id);
      if (!data) return errorResponse(res, "Not Found", 404);
      successResponse(res, data, "Deleted successfully");
    } catch (err) {
      next(err);
    }
  }
}
