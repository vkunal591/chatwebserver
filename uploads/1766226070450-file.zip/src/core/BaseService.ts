import { Model, Document } from "mongoose";

export class BaseService<T extends Document> {
  protected readonly model: Model<T>;

  constructor(model: Model<T>) {
    this.model = model;
  }

  // ✅ Create ONE document safely
  async create(data: Partial<T>): Promise<T> {
    const doc = new this.model(data);
    return await doc.save();
  }

  async findAll(
    filter: Record<string, any> = {},
    skip = 0,
    limit = 10,
    sort: Record<string, 1 | -1> = { createdAt: -1 }
  ): Promise<{ total: number; data: T[] }> {
    const [total, data] = await Promise.all([
      this.model.countDocuments(filter),
      this.model.find(filter).skip(skip).limit(limit).sort(sort),
    ]);

    return { total, data };
  }

  async findById(id: string): Promise<T | null> {
    return this.model.findById(id);
  }

  async update(id: string, data: Partial<T>): Promise<T | null> {
    return this.model.findByIdAndUpdate(id, data, {
      new: true,
      runValidators: true,
    });
  }

  async delete(id: string): Promise<T | null> {
    return this.model.findByIdAndDelete(id);
  }
}
