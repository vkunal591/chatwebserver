export abstract class BaseRepository {}
