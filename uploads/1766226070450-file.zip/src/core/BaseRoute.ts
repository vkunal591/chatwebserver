import { Router, RequestHandler } from "express";
// import { dynamicOwnerOrAdmin } from "../middlewares/AuthMiddleware";

type CrudAuth = {
  create?: boolean;
  getAll?: boolean;
  getById?: boolean;
  update?: boolean;
  delete?: boolean;
};

type DynamicCrudAuth = {
  [key: string]: {
    model: any;
    field: string;
  };
};

type ExtraRoute = {
  method: "get" | "post" | "put" | "delete";
  path: string;
  handler: RequestHandler;
  auth?: boolean;
  middleware?: RequestHandler[];
  role?: RequestHandler;
};

interface BaseRouteOptions {
  authMiddleware?: RequestHandler;
  crudAuth?: CrudAuth;
  roleCrudAuth?: Partial<Record<keyof CrudAuth, RequestHandler>>;
  dynamicCrudAuth?: DynamicCrudAuth;
  extraRoutes?: ExtraRoute[];
}

export class BaseRoute {
  protected router: Router;
  protected controller: any;
  protected authMiddleware: RequestHandler;
  protected crudAuth: CrudAuth;
  protected roleCrudAuth: Partial<Record<keyof CrudAuth, RequestHandler>>;
  protected dynamicCrudAuth: DynamicCrudAuth;
  protected extraRoutes: ExtraRoute[];

  constructor(controller: any, options: BaseRouteOptions = {}) {
    this.controller = controller;
    this.router = Router();

    this.authMiddleware = options.authMiddleware || ((_, __, next) => next());
    this.crudAuth = options.crudAuth || {};
    this.roleCrudAuth = options.roleCrudAuth || {};
    this.dynamicCrudAuth = options.dynamicCrudAuth || {};
    this.extraRoutes = options.extraRoutes || [];

    this.registerDefaultCrudRoutes();
    this.registerExtraRoutes();
  }

  private registerDefaultCrudRoutes(): void {
    this.createRoute("post", "/", "create");
    this.createRoute("get", "/", "getAll");
    this.createRoute("get", "/:id", "getById");
    this.createRoute("put", "/:id", "update");
    this.createRoute("delete", "/:id", "delete");
  }

  private createRoute(
    method: "get" | "post" | "put" | "delete",
    path: string,
    action: keyof CrudAuth
  ) {
    if (!this.controller[action]) return;

    const middlewares: RequestHandler[] = [];

    if (this.crudAuth[action]) middlewares.push(this.authMiddleware);
    if (this.roleCrudAuth[action]) middlewares.push(this.roleCrudAuth[action]!);

    if (this.dynamicCrudAuth[action]) {
      const { model, field } = this.dynamicCrudAuth[action];
      // middlewares.push(dynamicOwnerOrAdmin({ model, field }));
    }

    this.router[method](path, ...middlewares, this.controller[action]);
  }

  private registerExtraRoutes(): void {
    this.extraRoutes.forEach(route => {
      const middlewares: RequestHandler[] = [];

      if (route.auth) middlewares.push(this.authMiddleware);
      if (route.middleware) middlewares.push(...route.middleware);
      if (route.role) middlewares.push(route.role);

      this.router[route.method](
        route.path,
        ...middlewares,
        route.handler
      );
    });
  }

  public getRouter(): Router {
    return this.router;
  }
}
