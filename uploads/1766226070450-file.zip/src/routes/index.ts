import { Router } from "express";
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "../config/swagger";
import UserRoutes from "../modules/user/UserRoutes";
import AuthRoutes from "../modules/auth/AuthRoutes";
import PaymentRoutes from "../modules/paymentGateway/paymentRoutes"; // optional
import TransactionRoutes from "../modules/transaction/transactionRoute";
import serviceRoutes from "../modules/service/serviceRoutes";
import WalletRoutes from "../modules/wallet/walletRoutes"; // optional
import adminRoutes from "../modules/admin/adminRoutes"

const router = Router();

// Auth routes
router.use("/auth", AuthRoutes);
router.use("/user", UserRoutes);
router.use("/wallets", WalletRoutes);
router.use("/payments", PaymentRoutes);
router.use("/transactions", TransactionRoutes);
router.use('/services', serviceRoutes);
router.use('/admin', adminRoutes);
router.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

export default router;
