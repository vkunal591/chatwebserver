import express, { Application } from "express";
import cors from "cors";
import helmet from "helmet";
import routes from "./routes";
import { ErrorMiddleware } from "./middlewares/ErrorMiddleware";
import { HttpLoggerMiddleware } from "./middlewares/HttpLoggerMiddleware";
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "./config/swagger";

export class App {
  public readonly app: Application;

  constructor() {
    this.app = express();
    this.app.set("trust proxy", 1);
    this.initializeSwagger();
    this.middlewares();
    this.routes();
    this.errors();
  }
  private middlewares(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(cors());
    this.app.use(helmet());
    this.app.use(HttpLoggerMiddleware); // ✅ log all HTTP requests
  }


  private initializeSwagger(): void {
    this.app.use("/api/api-docs", (req, res, next) => {
      res.removeHeader("Cross-Origin-Opener-Policy");
      res.removeHeader("Origin-Agent-Cluster");
      next();
    });

    this.app.use(
      "/api/api-docs",
      swaggerUi.serve,
      swaggerUi.setup(swaggerSpec, {
        swaggerOptions: {
          url: "/api/api-docs",
        },
      })
    );

  }


  private routes(): void {
    this.app.get("/health", (_, res) =>
      res.status(200).json({ status: "ok" })
    );
    this.app.use("/api", routes);
  }

  private errors(): void {
    this.app.use(ErrorMiddleware.handle);
  }
}








