import { Request, Response, NextFunction } from "express";
import { Logger } from "../config/Logger";

export function HttpLoggerMiddleware(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();

  // Hook into response finish event
  res.on("finish", () => {
    const duration = Date.now() - start;
    const logMessage = `${req.method} ${req.originalUrl} ${res.statusCode} - ${duration}ms`;

    Logger.http(logMessage); // Save to HTTP log file
  });

  next();
}
