// Make sure Express types are imported
import { Request, Response, NextFunction } from "express";
import jwt, { JwtPayload } from "jsonwebtoken";
import { Env } from "../config/Env";
import { ApiError } from "../core/ApiError";

// Extend Express Request
export interface AuthRequest extends Request {
  user?: JwtPayload & { userID: string; role: string;[key: string]: any; };
}

export class AuthMiddleware {
  static verify(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      // Cast headers correctly
      const authHeader = req.headers['authorization'] as string | undefined;
        
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        throw new ApiError(401, "Unauthorized");
      }

      const token = authHeader.split(" ")[1];
      const decoded = jwt.verify(token, Env.JWT_SECRET) as AuthRequest["user"];

      req.user = decoded;
      next();
    } catch (err) {
      console.log(err);

      next(new ApiError(401, "Invalid token"));
    }
  }
}
