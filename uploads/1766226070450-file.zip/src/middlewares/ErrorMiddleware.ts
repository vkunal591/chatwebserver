import { Request, Response, NextFunction } from "express";

export class ErrorMiddleware {
  static handle(err: any, req: Request, res: Response, next: NextFunction) {
    res.status(500).json({ success: false, message: err.message });
  }
}
