import dotenv from "dotenv";

export class Env {
  static PORT: number;
  static DB_URL: string;
  static JWT_SECRET: string;
  static JWT_EXPIRES_IN: string | number;
  static ADMIN_BASE_URL: string | undefined;
  static APIKEY: string | undefined;
  static NODE_ENV: string | undefined;

  static load(): void {
    dotenv.config();

    const required = ["PORT", "DB_URL", "JWT_SECRET", "JWT_EXPIRES_IN", "ADMIN_BASE_URL", "APIKEY", "NODE_ENV"] as const;

    required.forEach((key) => {
      if (!process.env[key]) {
        throw new Error(`Missing env: ${key}`);
      }
    });

    const port = Number(process.env.PORT);
    if (Number.isNaN(port)) {
      throw new Error("PORT must be a number");
    }

    this.PORT = port;
    this.DB_URL = process.env.DB_URL!;
    this.JWT_SECRET = process.env.JWT_SECRET!;
    this.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN!;
    this.ADMIN_BASE_URL = process.env.ADMIN_BASE_URL;
    this.APIKEY = process.env.APIKEY;
    this.NODE_ENV = process.env.NODE_ENV;
  }
}
