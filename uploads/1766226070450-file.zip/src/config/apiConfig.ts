import { Env } from "./Env";

interface ApiEndpoint {
  name: string;
  url: string;
  method: "GET" | "POST";
  apiKey?: string;
}

const baseurl = Env.ADMIN_BASE_URL || "http://72.61.159.48";
const apiKey = Env.APIKEY || "12";
export const apiEndpoints: ApiEndpoint[] = [
  {
    name: "currentBalance",
    url: `${baseurl}/get-current-balance`,
    method: "GET",
    apiKey: apiKey
  },
  {
    name: "getBillerDetails",
    url: `${baseurl}/get-biller-details`,
    method: "GET",
    apiKey: apiKey
  },
  {
    name: "postBillFetch",
    url: `${baseurl}/post-bill-fetch`,
    method: "POST",
    apiKey: apiKey
  },
  {
    name: "addFund",
    url: `${baseurl}/add-money-request`,
    method: "POST",
    apiKey: apiKey
  },
  {
    name: "verify",
    url: `${baseurl}/check-response`,
    method: "POST",
    apiKey: apiKey
  }
];
