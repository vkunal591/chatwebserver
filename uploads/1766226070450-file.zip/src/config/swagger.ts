import swaggerJsdoc from "swagger-jsdoc";

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "My API",
      version: "1.0.0",
      description: "API documentation with Swagger",
    },
    servers: [
      {
        url: "{protocol}://{host}/api",
        variables: {
          protocol: {
            enum: ["http"],
            default: "http",
          },
          host: {
            default: "localhost:5000",
          },
        },
      },
    ],
  },
  apis: [
    "./src/modules/auth/AuthRoutes.ts",
    "./src/modules/admin/adminRoutes.ts",
    "./src/modules/paymentGateway/paymentRoutes.ts",
    "./src/modules/service/serviceRoutes.ts",
    "./src/modules/transaction/transactionRoute.ts",
    "./src/modules/user/UserRoutes.ts",
    "./src/modules/wallet/walletRoutes.ts",
  ],
};

export const swaggerSpec = swaggerJsdoc(options);
