import mongoose from "mongoose";
import { Env } from "./Env";
import { Logger } from "./Logger";

export class Database {
  static async connect(): Promise<void> {
    await mongoose.connect(Env.DB_URL);
    Logger.info("Database connected");
  }
}
