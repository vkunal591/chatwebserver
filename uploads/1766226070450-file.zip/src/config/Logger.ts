import fs from "fs";
import path from "path";
import "colors";

type LogLevel =
  | "INFO"
  | "WARN"
  | "ERROR"
  | "DEBUG"
  | "HTTP"
  | "SUCCESS"
  | "FATAL"
  | "EXCEPTION";

export class Logger {
  // ✅ Always create logs folder at project root
  private static logDir = path.resolve(process.cwd(), "logs");

  // Initialize: create folder if missing
  static init(): void {
    try {
      if (!fs.existsSync(this.logDir)) {
        fs.mkdirSync(this.logDir, { recursive: true });
        console.log("✅ Log directory created at".green, this.logDir);
      } else {
        console.log("✅ Log directory exists at".green, this.logDir);
      }
    } catch (err) {
      console.error("❌ Failed to create log directory:", err);
    }
  }

  // Single daily log file
  private static getLogFile(): string {
    const date = new Date().toISOString().split("T")[0];
    return path.join(this.logDir, `${date}.log`);
  }

  // Async write to log file
  private static write(
    level: LogLevel,
    message: string,
    stack?: string
  ): void {
    const timestamp = new Date().toISOString();
    const log =
      `${timestamp} [${level}]: ${message}` +
      (stack ? `\n${stack}` : "") +
      "\n";

    fs.appendFile(this.getLogFile(), log, { encoding: "utf8" }, (err) => {
      if (err) {
        console.error("❌ Failed to write log:", err);
      }
    });

    // Console output
    if (
      process.env.NODE_ENV !== "production" ||
      ["ERROR", "FATAL", "EXCEPTION"].includes(level)
    ) {
      switch (level) {
        case "INFO":
          console.log(message.blue);
          break;
        case "WARN":
          console.warn(message.yellow);
          break;
        case "ERROR":
          console.error(message.red);
          break;
        case "DEBUG":
          console.log(message.gray);
          break;
        case "HTTP":
          console.log(message.cyan);
          break;
        case "SUCCESS":
          console.log(message.green);
          break;
        case "FATAL":
        case "EXCEPTION":
          console.error(message.bgRed.white);
          break;
      }
    }
  }

  // ===== Log methods =====
  static info(message: string): void {
    this.write("INFO", message);
  }

  static warn(message: string): void {
    this.write("WARN", message);
  }

  static error(message: string, error?: Error): void {
    this.write("ERROR", message, error?.stack);
  }

  static debug(message: string): void {
    this.write("DEBUG", message);
  }

  static http(message: string): void {
    this.write("HTTP", message);
  }

  static success(message: string): void {
    this.write("SUCCESS", message);
  }

  static fatal(message: string, error?: Error): never {
    this.write("FATAL", message, error?.stack);
    process.exit(1);
  }

  static exception(error: Error): void {
    this.write("EXCEPTION", error.message, error.stack);
  }
}
