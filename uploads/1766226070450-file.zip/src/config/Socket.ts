import { Server } from "socket.io";
import { Logger } from "./Logger";

export class Socket {
  constructor(httpServer: any) {
    const io = new Server(httpServer, { cors: { origin: "*" } });
    io.on("connection", socket => {
      Logger.info(`Socket connected: ${socket.id}`);
    });
  }
}
