// src/types/auth.ts
import { Request } from "express";
import { JwtPayload } from "jsonwebtoken";

export interface AuthenticatedUser extends JwtPayload {
    userID: string;   // MongoDB user _id
    role: string;
}

// Extend Express Request to include the authenticated user
export interface AuthRequest extends Request {
    user?: AuthenticatedUser;
}
