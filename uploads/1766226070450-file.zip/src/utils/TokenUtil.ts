import jwt, { JwtPayload, SignOptions } from "jsonwebtoken";
import { Env } from "../config/Env";

export interface AuthTokenPayload {
  userID: string;
  role: string;
}

export class TokenUtil {
  // =========================
  // Generate JWT Token
  // =========================
  static generateToken(
    payload: AuthTokenPayload,
    options?: SignOptions
  ): string {
    return jwt.sign(payload, Env.JWT_SECRET, {
      expiresIn: Env.JWT_EXPIRES_IN,
      ...options,
    });
  }

  // =========================
  // Verify JWT Token
  // =========================
  static verifyToken(token: string): JwtPayload & AuthTokenPayload {
    return jwt.verify(token, Env.JWT_SECRET) as JwtPayload & AuthTokenPayload;
  }

  // =========================
  // Decode JWT (no verify)
  // =========================
  static decodeToken(token: string): JwtPayload | null {
    return jwt.decode(token) as JwtPayload | null;
  }
}
