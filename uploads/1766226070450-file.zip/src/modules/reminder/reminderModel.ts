import mongoose, { Schema, model, Document } from "mongoose";


export interface IBillResponse {
    accountHash:string;
    billerId:string;
    parameters: any;
    userID:string;
    requestID:string;
}

export interface BillReponseDocument extends IBillResponse, Document {
    createdAt: Date;
    updatedAt: Date;
}


const BillResponseSchema = new Schema<BillReponseDocument>(
    {
        parameters: {
            type: mongoose.Schema.Types.Mixed,
            default:{}
        },
        accountHash:{
            type:String
        },
        billerId:{
            type:String
        },
        userID:{
            type:String
        },
        requestID:{
            type:String
        }
    },
    {
        timestamps: true,
        versionKey: false,
    }
);




export const BillReminder = model<BillReponseDocument>("BillReminder", BillResponseSchema);
