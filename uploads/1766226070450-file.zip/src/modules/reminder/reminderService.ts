import { ApiError } from "../../core/ApiError";
import { BillReminder, BillReponseDocument, IBillResponse } from "./reminderModel";

import crypto from "crypto";

export class ReminderService {


    async getReminders(userID: string, billerId: string): Promise<BillReponseDocument[]> {
        try {
            if (!userID || userID.trim() === "") {
                throw new ApiError(400, "userID is required");
            }
            if (!billerId || billerId.trim() === "") {
                throw new ApiError(400, "billerId is required");
            }
            const reminders = await BillReminder.find({ userID, billerId })
            console.log(billerId, reminders)
            return reminders;

        } catch (error: any) {
            throw new ApiError(500, "Failed to fetch reminders");
        }
    }

    async reminderApi(
        parameters: Record<string, any>,
        apiResponse: Record<string, any>,
        billerId: string,
        userID: string,
        requestID: string
    ): Promise<BillReponseDocument> {
        try {
            console.log(parameters)
            if (!parameters || typeof parameters !== "object") {
                throw new ApiError(400, "Invalid API response");
            }

            const stableStringify = (obj: Record<string, any>) =>
                JSON.stringify(
                    Object.keys(obj)
                        .sort()
                        .reduce((acc: Record<string, any>, key: string) => {
                            acc[key] = obj[key];
                            return acc;
                        }, {})
                );
            console.log(parameters)
            const responseString = stableStringify(parameters);

            // Generate hashes
            const sha256Hash = crypto.createHash("sha256").update(responseString).digest("hex");

            const accountHash = sha256Hash;

            const isReminderAvailable = await BillReminder.findOne({ accountHash, userID })

            let billResponse;
            if (isReminderAvailable) {
                isReminderAvailable.requestID = requestID
                await isReminderAvailable.save()
                return isReminderAvailable;
            }

            billResponse = await BillReminder.create({
                accountHash,
                billerId,
                userID,
                requestID,
                parameters: apiResponse,
            });

            return billResponse;

        } catch (error: any) {
            throw new ApiError(500, "Failed to save bill reminder");
        }
    }


    // async reminderApi(
    //     apiResponse: Record<string, any>,
    //     billerId: string,
    //     userID: string,
    //     requestID: string
    // ): Promise<BillReponseDocument> {
    //     try {
    //         if (!apiResponse || typeof apiResponse !== "object") {
    //             throw new ApiError(400, "Invalid API response");
    //         }

    //         // Stable stringify to ensure consistent hash
    //         const stableStringify = (obj: Record<string, any>) =>
    //             JSON.stringify(
    //                 Object.keys(obj)
    //                     .sort()
    //                     .reduce((acc: Record<string, any>, key: string) => {
    //                         acc[key] = obj[key];
    //                         return acc;
    //                     }, {})
    //             );

    //         const responseString = stableStringify(apiResponse);

    //         // Generate hashes
    //         const md5Hash = crypto.createHash("md5").update(responseString).digest("hex");
    //         const sha256Hash = crypto.createHash("sha256").update(responseString).digest("hex");
    //         const accountHash = sha256Hash;

    //         // Update existing reminder if userID + billerId exists, otherwise create new
    //         const billResponse = await BillReminder.findOneAndUpdate(
    //             { userID, billerId }, // query
    //             {
    //                 accountHash,
    //                 requestID,
    //                 parameters: apiResponse,
    //             },
    //             { new: true, upsert: true } // upsert: create if not exists, new: return updated doc
    //         );

    //         return billResponse;

    //     } catch (error: any) {
    //         throw new ApiError(500, "Failed to save bill reminder");
    //     }
    // }

}




