import { Request, Response } from "express";
import { TransactionService } from "./transactionService";

export class TransactionController {
  // Create a new transaction
  createTransaction = async (req: Request, res: Response) => {
    try {
      const { userID, amount, operator } = req.body;
      if (!userID || !amount || !operator) {
        return res.status(400).json({ success: false, message: "userID, amount, operator required" });
      }

      const transaction = await TransactionService.createTransaction(userID, Number(amount), operator);

      res.json({ success: true, data: transaction });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  };

  // Get transactions (by transactionID, userID, or status)
  getTransaction = async (req: Request, res: Response) => {
    try {
      const { transactionID, userID, status } = req.query;

      const transactions = await TransactionService.getTransaction({
        transactionID: transactionID as string,
        userID: userID as string,
        status: status as string,
      });

      res.json({ success: true, data: transactions });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  };





  filterTransactions = async (req: Request, res: Response) => {
    try {
      const { transactionID, userID, status, operator, minAmount, maxAmount, startDate, endDate } = req.query;

      const transactions = await TransactionService.filterTransactions({
        transactionID: transactionID as string,
        userID: userID as string,
        status: status as string,
        operator: operator as string,
        minAmount: minAmount ? Number(minAmount) : undefined,
        maxAmount: maxAmount ? Number(maxAmount) : undefined,
        startDate: startDate as string,
        endDate: endDate as string,
      });

      res.json({ success: true, data: transactions });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  };
}
