import { Schema, model, Document } from "mongoose";

export type TransactionStatus = "PENDING" | "SUCCESS" | "FAILED";

export interface ITransaction {
  userID: string;
  walletID: string;
  amount: number;
  operator: string;
  status: TransactionStatus;
  transactionID: string;
}

export interface TransactionDocument extends ITransaction, Document {
  createdAt:Date,
  updatedAt:Date
}

const transactionSchema = new Schema<TransactionDocument>(
  {
    userID: { type: String, required: true },
    walletID: { type: String, required: true },
    amount: { type: Number, required: true },
    operator: { type: String, required: true },
    status: { type: String, enum: ["PENDING", "SUCCESS", "FAILED"], default: "PENDING" },
    transactionID: { type: String, required: true, unique: true },
  },
  { timestamps: true }
);

export const TransactionModel = model<TransactionDocument>("Transaction", transactionSchema);
