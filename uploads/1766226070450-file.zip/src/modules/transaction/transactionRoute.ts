import { Router } from "express";
import { TransactionController } from "./transactionController";

const router = Router();
const controller = new TransactionController();


/**
 * @swagger
 * /api/transactions/create:
 *   post:
 *     summary: Create Transaction
 *     tags: [Transaction Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               amount:
 *                 type: number
 *               operator:
 *                 type: string
 *               userID:
 *                 type: string
 *     responses:
 *       201:
 *         description: Transaction created success
 */
router.post("/create", controller.createTransaction);

/**
 * @swagger
 * /api/transactions:
 *   get:
 *     summary: Get Transaction
 *     tags: [Transaction Apis]
 *     responses:
 *       201:
 *         description: get transaction success
 */
router.get("/", controller.getTransaction);

/**
 * @swagger
 * /api/transactions/filter:
 *   post:
 *     summary: Filter Transaction
 *     tags: [Transaction Apis]
 *     responses:
 *       201:
 *         description: Filter Transaction success
 */
router.post("/filter", controller.filterTransactions);


export default router;
