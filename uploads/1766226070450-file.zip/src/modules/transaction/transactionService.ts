import crypto from "crypto";
import { WalletService } from "../wallet/walletService";
import { TransactionModel } from "./transactionModel";
import { WalletModel } from "../wallet/walletModel";

export class TransactionService {
  
 static async createTransaction(userID: string, amount: number, operator: string) {
  // 1. Find wallet
  const wallet = await WalletModel.findOne({ userID });
  if (!wallet) throw new Error("Wallet not found");

  const transactionID = crypto.randomUUID();

  // 2. Create a pending transaction
  const transaction = await TransactionModel.create({
    userID,
    walletID: wallet._id.toString(),
    amount,
    operator,
    transactionID,
    status: "PENDING",
  });

  try {
    // 3. Update wallet directly (no session)
    if (!wallet.balance) wallet.balance = 0;
    wallet.balance += amount; // CREDIT operation
    await wallet.save();

    // 4. Mark transaction success
    transaction.status = "SUCCESS";
    await transaction.save();

    return transaction;
  } catch (err) {
    // 5. Mark transaction failed
    transaction.status = "FAILED";
    await transaction.save();
    throw err;
  }
}

  // ===== GET TRANSACTION METHOD =====
  static async getTransaction({ transactionID, userID, status }: { transactionID?: string; userID?: string; status?: string }) {
    const query: any = {};

    if (transactionID) query.transactionID = transactionID;
    if (userID) query.userID = userID;
    if (status) query.status = status;

    const transactions = await TransactionModel.find(query).sort({ createdAt: -1 });
    return transactions;
  }


  

  static async filterTransactions(filters: {
    transactionID?: string;
    userID?: string;
    status?: string;
    operator?: string;
    minAmount?: number;
    maxAmount?: number;
    startDate?: string;
    endDate?: string;
  }) {
    const query: any = {};

    if (filters.transactionID) query.transactionID = filters.transactionID;
    if (filters.userID) query.userID = filters.userID;
    if (filters.status) query.status = filters.status;
    if (filters.operator) query.operator = filters.operator;
    if (filters.minAmount || filters.maxAmount) {
      query.amount = {};
      if (filters.minAmount) query.amount.$gte = filters.minAmount;
      if (filters.maxAmount) query.amount.$lte = filters.maxAmount;
    }
    if (filters.startDate || filters.endDate) {
      query.createdAt = {};
      if (filters.startDate) query.createdAt.$gte = new Date(filters.startDate);
      if (filters.endDate) query.createdAt.$lte = new Date(filters.endDate);
    }

    return TransactionModel.find(query).sort({ createdAt: -1 });
  }
}
