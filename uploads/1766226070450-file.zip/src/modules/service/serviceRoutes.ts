// import { Router } from "express";
// import { ServiceController } from "./serviceController";
// import { ServiceDataService } from "./serviceDataService";

// const router = Router();

// const service = new ServiceDataService();

// const controller = new ServiceController(service);

// router.get('/get_category_list', controller.getCategoryList);


// router.get('/get_data_by_category', controller.getDataByCategory);

// export default router;



import { Router } from "express";
import { ServiceController } from "./serviceController";

const serviceRoutes = Router();
const controller = new ServiceController();

// Category list

/**
 * @swagger
 * /api/services/categories:
 *   get:
 *     summary: Get Categories
 *     tags: [Services Apis]
 *     responses:
 *       201:
 *         description: Get categories success
 */
serviceRoutes.get("/categories", controller.getCategories);

// Services by category

/**
 * @swagger
 * /api/services/categories/:category/services:
 *   get:
 *     summary: Get services by category
 *     tags: [Services Apis]
 *     responses:
 *       201:
 *         description: Get services by category success
 */
serviceRoutes.get("/categories/:category/services", controller.getServicesByCategory);


/**
 * @swagger
 * /api/services/categories-with-services:
 *   get:
 *     summary: Get category with services
 *     tags: [Services Apis]
 *     responses:
 *       201:
 *         description: Get category with services success
 */
serviceRoutes.get("/categories-with-services", controller.getCategoriesWithServices);

// Service providers 

/**
 * @swagger
 * /api/services/categories/services/:serviceName/providers:
 *   get:
 *     summary: Get services provider
 *     tags: [Services Apis]
 *     responses:
 *       201:
 *         description: Get services provider success
 */
serviceRoutes.get(
    "/categories/services/:serviceName/providers",
    controller.getServiceProviders
);

export default serviceRoutes;
