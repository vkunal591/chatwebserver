export interface Service {
    name: string;
    icon?: string;
}

export interface CategoryItem {
    category: string;
    icon?: string;
    services: Service[];
}

export interface ProvidersItems {
    blr_id: string;
    blr_name: string;
    blr_alias_name: string;
    blr_category_name: string;
    blr_coverage: string;
}

const serviceData: CategoryItem[] = require("../../../category.json");
const serviceProviderData: ProvidersItems[] = require("../../../billinfo.json");

export class ServiceDataService {

    async getCategoryList() {
        return {
            success: true,
            data: serviceData.map(item => item.category),
            message: serviceData.length
                ? "Categories fetched successfully"
                : "No categories available"
        };
    }

    async getServicesByCategory(category: string) {
        if (!category) {
            return {
                success: false,
                data: [],
                message: "Category is required"
            };
        }

        const categoryData = serviceData.find(
            item => item.category.toLowerCase() === category.toLowerCase()
        );

        if (!categoryData) {
            return {
                success: false,
                data: [],
                message: "Category not found"
            };
        }

        return {
            success: true,
            data: categoryData.services || [],
            message: categoryData.services?.length
                ? "Services fetched successfully"
                : "No services available for this category"
        };
    }

    async getCategoriesWithServicesAndIcons() {
        if (!serviceData || serviceData.length === 0) {
            return {
                success: true,
                data: [],
                message: "No categories available"
            };
        }

        const data = serviceData.map(item => ({
            category: item.category,
            categoryIcon: item.icon || null,
            services: item.services?.map((s: Service) => ({
                name: s.name,
                icon: s.icon || null
            })) || []
        }));

        return {
            success: true,
            data,
            message: "Categories with services fetched successfully"
        };
    }

    /**
     * Get service providers for a given category and service
     */

    async getServiceProviders(serviceName?: string) {
        // If category and serviceName both not provided, return all providers
        let filteredProviders = serviceProviderData;



        if (serviceName) {
            filteredProviders = filteredProviders.filter(
                provider => provider.blr_category_name.toLowerCase() === serviceName.toLowerCase()
            );

            // Service exists check
            const serviceExists = serviceData.some(
                cat =>
                    cat.services?.some(
                        s => s.name.toLowerCase() === serviceName.toLowerCase()
                    )
            );

            if (!serviceExists) {
                return {
                    success: true,
                    data: [],
                    message: "Service does not exist in any category"
                };
            }
        }

        return {
            success: true,
            data: filteredProviders,
            message: filteredProviders.length
                ? "Service providers fetched successfully"
                : "No service providers available"
        };
    }

}
