// import {ServiceDataService} from "./serviceDataService";
// import { Request,Response,NextFunction } from "express";
// import { successResponse } from "../../core/ApiResponse";

// export class ServiceController {
//     constructor(private service: ServiceDataService) {}

//     getCategoryList = async (
//         req: Request,
//         res: Response,
//         next: NextFunction
//     ) => {
//         try {
//             const categories = await this.service.categoryList();
//             return successResponse(
//                 res,
//                 categories,
//                 "Category list fetched successfully!"
//             );
//         } catch (error) {
//             next(error);
//         }
//     };


//     getDataByCategory = async (
//         req: Request,
//         res: Response,
//         next: NextFunction
//     ) => {
//         try {
//             // const { category } = req.query;

//             // if (!category) {
//             //     throw new Error("Category is required");
//             // }

//             const data = await this.service.getDataByCategory(
//                 // category as string
//             );

//             return successResponse(
//                 res,
//                 data,
//                 "Category data fetched successfully!"
//             );
//         } catch (error) {
//             next(error);
//         }
//     };
// }



import { Request, Response } from "express";
import { ServiceDataService } from "./serviceDataService";

const service = new ServiceDataService();

export class ServiceController {

    async getCategories(req: Request, res: Response) {
        const result = await service.getCategoryList();
        return res.status(200).json(result);
    }

    async getServicesByCategory(req: Request, res: Response) {
        const { category } = req.params;
        const result = await service.getServicesByCategory(category);
        return res.status(result.success ? 200 : 400).json(result);
    }

    async getCategoriesWithServices(req: Request, res: Response) {
        const result = await service.getCategoriesWithServicesAndIcons();
        return res.status(200).json(result);
    }

    async getServiceProviders(req: Request, res: Response) {
        const { serviceName } = req.params;
        const result = await service.getServiceProviders(serviceName);
        return res.status(result.success ? 200 : 400).json(result);
    }
}
