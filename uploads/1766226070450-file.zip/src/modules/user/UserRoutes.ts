import { Router } from "express";
import { UserController } from "./UserController";
import { AuthMiddleware } from "../../middlewares/AuthMiddleware";
import { authorizeRoles } from "../../middlewares/authorizeRoles";

const router = Router();


/**
 * @swagger
 * /api/user/register:
 *   post:
 *     summary: Register User
 *     tags: [User Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               userName:
 *                 type: string
 *               mobileNumber:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       201:
 *         description: Register User success
 */
router.post("/register", AuthMiddleware.verify, authorizeRoles(['admin']), UserController.createUser);

/**
 * @swagger
 * /api/user/:id:
 *   put:
 *     summary: Update User success
 *     tags: [User Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               userName:
 *                 type: string
 *               mobileNumber:
 *                 type: string
 *     responses:
 *       201:
 *         description: Update User success
 */
router.put("/:id", AuthMiddleware.verify, UserController.updateUser);

/**
 * @swagger
 * /api/user/:id:
 *   get:
 *     summary: Get User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: Get User success
 */
router.get("/:id", AuthMiddleware.verify, UserController.getUser);

/**
 * @swagger
 * /api/user:
 *   get:
 *     summary: List User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: List User success
 */
router.get("/", AuthMiddleware.verify, UserController.listUsers);

/**
 * @swagger
 * /api/user/deleted/list:
 *   get:
 *     summary: List soft deleted User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: List soft deleted user success
 */
router.get("/deleted/list", AuthMiddleware.verify, UserController.listSoftDeletedUsers);

/**
 * @swagger
 * /api/user/active/list:
 *   get:
 *     summary: List active User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: List active user success
 */
router.get("/active/list", AuthMiddleware.verify, UserController.listActiveUsers);

/**
 * @swagger
 * /api/user/delete/:id:
 *   delete:
 *     summary:  Soft Delete User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: Soft deleted user success
 */
router.delete("/delete/:id", AuthMiddleware.verify, UserController.softDeleteUser);

/**
 * @swagger
 * /api/user/restore/:id:
 *   put:
 *     summary:  Restore Deleted User
 *     tags: [User Apis]
 *     responses:
 *       201:
 *         description: Restore deleted user success
 */
router.put("/restore/:id", AuthMiddleware.verify, UserController.restoreUser);



export default router;
