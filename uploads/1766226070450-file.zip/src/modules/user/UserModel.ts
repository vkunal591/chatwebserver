import { Schema, model, Document } from "mongoose";
import bcrypt from "bcrypt";

/**
 * User interface
 */
export interface IUser {
  userName: string;
  mobileNumber: string;
  password: string;
  twoStepEnabled: boolean;
  apiKey: string;
  ip: string[];
  walletBalance: {
    refund: number;
    credit: number;
    debit: number;
    amount: number;
    walletID: string;
    availableBalance: number;
    date: Date;
  };
  isDeleted?: boolean;
  role: string;
}

/**
 * Document interface
 */
export interface UserDocument extends IUser, Document {
  createdAt: Date;
  updatedAt: Date;
  verifyPassword(password: string): Promise<boolean>;
}

/**
 * Schema
 */
const UserSchema = new Schema<UserDocument>(
  {
    userName: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    mobileNumber: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
      select: false, // 🔐 important
    },
    twoStepEnabled: {
      type: Boolean,
      default: false,
    },
    apiKey: {
      type: String,
      required: true,
    },
    ip: {
      type: [String],
      default: [],
    },
    walletBalance: {
      refund: { type: Number, default: 0 },
      credit: { type: Number, default: 0 },
      debit: { type: Number, default: 0 },
      amount: { type: Number, default: 0 },
      walletID: { type: String, required: true },
      availableBalance: { type: Number, default: 0 },
      date: { type: Date, default: Date.now },
    },
    role: {
      type: String,
      enum: ["user", "admin", "support"],
      default: "user",
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

/**
 * Password hashing
 */
UserSchema.pre<UserDocument>("save", async function () {
  if (!this.isModified("password")) return;

  const saltRounds = 10;
  this.password = await bcrypt.hash(this.password, saltRounds);
});


/**
 * Password verification
 */
UserSchema.methods.verifyPassword = async function (
  password: string
): Promise<boolean> {
  return bcrypt.compare(password, this.password);
};

/**
 * Model
 */
export const User = model<UserDocument>("User", UserSchema);
