import { User } from "./UserModel";

export class UserRepository {
  findAll() {
    return User.find();
  }
}
