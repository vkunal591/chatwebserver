import { Request, Response, NextFunction } from "express";
import { CreateUserDTO, UserService } from "./UserService";
import { AuthRequest } from "../../types/userType";

export class UserController {

  static async createUser(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const body: CreateUserDTO = req.body; // assert correct type
      const user = await UserService.createUserByAdmin(body);
      res.status(201).json({ success: true, data: user });
    } catch (err: any) {
      next(err);
    }
  }

  static async updateUser(req: Request, res: Response, next: NextFunction) {
    try {
      const authReq = req as Request & { user?: { userID: string; role: string } };
      const user = await UserService.updateUser(req.params.id, req.body);
      res.json({ success: true, data: user });
    } catch (err: any) {
      next(err);
    }
  }

  static async getUser(req: Request, res: Response, next: NextFunction) {
    try {
      const authReq = req as Request & { user?: { userID: string; role: string } };
      const user = await UserService.getUser(req.params.id);
      res.json({ success: true, data: user });
    } catch (err: any) {
      res.status(404).json({ success: false, message: err.message });
    }
  }

  static async softDeleteUser(req: Request, res: Response, next: NextFunction) {
    try {
      const authReq = req as Request & { user?: { userID: string; role: string } };
      const result = await UserService.softDeleteUser(req.params.id);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(404).json({ success: false, message: err.message });
    }
  }

  static async restoreUser(req: Request, res: Response, next: NextFunction) {
    try {
      const authReq = req as Request & { user?: { userID: string; role: string } };
      const result = await UserService.restoreUser(req.params.id);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(404).json({ success: false, message: err.message });
    }
  }

  static async listUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const users = await UserService.listUsers();
      res.json({ success: true, data: users });
    } catch (err: any) {
      next(err);
    }
  }

  static async listSoftDeletedUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const users = await UserService.listSoftDeletedUsers();
      res.json({ success: true, data: users });
    } catch (err: any) {
      next(err);
    }
  }

  static async listActiveUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const users = await UserService.listSoftNotDeletedUsers();
      res.json({ success: true, data: users });
    } catch (err: any) {
      next(err);
    }
  }
}
