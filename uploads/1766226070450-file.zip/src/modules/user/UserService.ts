import crypto from "crypto";
import { User, UserDocument } from "./UserModel";
import { WalletLedgerModel, WalletLedgerType } from "../wallet/walletLedgerModel";
import { WalletModel } from "../wallet/walletModel";

export interface CreateUserDTO {
  userName: string;
  mobileNumber: string;
  password: string;
  role?: "user" | "admin" | "support";
  walletPin?: string;
  initialBalance?: number;
}

export class UserService {
  /**
   * Admin creates a new user with automatic wallet and initial ledger
   */
  static async createUserByAdmin(
    data: CreateUserDTO
  ): Promise<Partial<UserDocument>> {

    const walletID = crypto.randomUUID();
    const apiKey = crypto.randomUUID();
    const initialBalance = data.initialBalance || 0;

    const user: UserDocument = await User.create({
      userName: data.userName,
      mobileNumber: data.mobileNumber,
      password: data.password,
      role: data.role || "user",
      apiKey,
      ip: [],
      walletBalance: {
        walletID,
        refund: 0,
        credit: initialBalance,
        debit: 0,
        amount: initialBalance,
        availableBalance: initialBalance,
        date: new Date(),
      },
    });

    const wallet = new WalletModel({
      walletID,
      userID: user._id.toString(),
      balance: initialBalance,
      isActive: true,
      pinHash: "TEMP",
    });

    await wallet.setPin(data.walletPin || "1234");
    await wallet.save();

    await WalletLedgerModel.create({
      walletID,
      userID: user._id.toString(),
      type: "CREDIT",
      amount: initialBalance,
      opening: 0,
      closing: initialBalance,
      status: "SUCCESS",
      transactionID: crypto.randomUUID(),
      date: new Date(),
    });

    const safeUser = user.toObject();
    delete (safeUser as any).password;

    return safeUser;
  }


  /**
   * Update user info
   */
  static async updateUser(userID: string, data: Partial<UserDocument>) {
    const user = await User.findById(userID);
    if (!user) throw new Error("User not found");

    // Prevent updating sensitive fields directly
    delete data.password;
    delete data.walletBalance;

    Object.assign(user, data);
    await user.save();

    const safeUser = user.toObject();
    delete (safeUser as any).password;
    delete (safeUser as any).pin;
    return safeUser;

  }

  /**
   * Get user by ID (hide sensitive info)
   */
  static async getUser(userID: string) {
    const user = await User.findById(userID);
    if (!user) throw new Error("User not found");

    const safeUser = user.toObject();
    delete (safeUser as any).password;
    delete (safeUser as any).pin;
    return safeUser;

  }

  /**
   * List all users (hide sensitive info)
   */
  static async listUsers() {
    const users = await User.find();
    return users.map((user) => {
      const safeUser = user.toObject();
      delete (safeUser as any).password;
      delete (safeUser as any).pin;
      return safeUser;

    });
  }


  // List only soft-deleted users
  static async listSoftDeletedUsers() {
    const users = await User.find({ isDeleted: true });

    return users.map((user) => {
      const safeUser = user.toObject();
      delete (safeUser as any).password; // remove password
      delete (safeUser as any).pin;      // remove pin if exists
      return safeUser;
    });
  }

  // List only soft-deleted users
  static async listSoftNotDeletedUsers() {
    const users = await User.find({ isDeleted: false });

    return users.map((user) => {
      const safeUser = user.toObject();
      delete (safeUser as any).password; // remove password
      delete (safeUser as any).pin;      // remove pin if exists
      return safeUser;
    });
  }
  static async softDeleteUser(userID: string) {
    const user = await User.findByIdAndUpdate(
      userID,
      { isDeleted: true },
      { new: true }
    ).select("-password -__v");

    if (!user) {
      throw new Error("User not found");
    }

    return {
      message: "User soft deleted successfully",
      user,
    };
  }

  // Optional: Restore user
  static async restoreUser(userID: string) {
    const user = await User.findByIdAndUpdate(
      userID,
      { isDeleted: false },
      { new: true }
    ).select("-password -__v");

    if (!user) {
      throw new Error("User not found");
    }

    return {
      message: "User restored successfully",
      user,
    };
  }

}
