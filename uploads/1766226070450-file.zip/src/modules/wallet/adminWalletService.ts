import { WalletModel } from "../wallet/walletModel";
import { WalletLedgerModel } from "../wallet/walletLedgerModel";

export class AdminWalletService {
  static async reconcile(userID: string) {
    const wallet = await WalletModel.findOne({ userID });
    if (!wallet) throw new Error("Wallet not found");

    const ledgerSum = await WalletLedgerModel.aggregate([
      { $match: { userID, status: "SUCCESS" } },
      {
        $group: {
          _id: null,
          balance: {
            $sum: {
              $cond: [
                { $eq: ["$type", "CREDIT"] },
                "$amount",
                { $multiply: ["$amount", -1] },
              ],
            },
          },
        },
      },
    ]);

    const calculatedBalance = ledgerSum[0]?.balance ?? 0;

    return {
      walletBalance: wallet.balance,
      ledgerBalance: calculatedBalance,
      mismatch: wallet.balance !== calculatedBalance,
    };
  }
}
