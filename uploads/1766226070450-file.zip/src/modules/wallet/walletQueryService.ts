import { WalletModel } from "./walletModel";
import { WalletLedgerModel } from "./walletLedgerModel";
import mongoose from "mongoose";

export class WalletQueryService {

  static async getWalletByUser(userID: string) {
    const wallet = await WalletModel.findOne({ userID });
    if (!wallet) throw new Error("Wallet not found");
    const safeWallet = wallet.toObject();
    delete (safeWallet as any).pinHash;
    return safeWallet;
  }

  static async getLedger(userID: string) {
    const ledger = await WalletLedgerModel.find({ userID }).sort({ date: -1 });
    return ledger;
  }
}
