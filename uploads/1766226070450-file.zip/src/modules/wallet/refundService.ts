import crypto from "crypto";
import { WalletLedgerModel } from "../wallet/walletLedgerModel";
import { WalletService } from "../wallet/walletService";

export class RefundService {
    static async refund(
        walletID: string,
        userID: string,
        originalTransactionID: string,
        amount: number
    ) {
        if (amount <= 0) {
            throw new Error("Invalid refund amount");
        }

        // 🔍 Ensure original transaction exists
        const originalTxn = await WalletLedgerModel.findOne({
            transactionID: originalTransactionID,
            type: "DEBIT",
            status: "SUCCESS",
        });

        if (!originalTxn) {
            throw new Error("Original transaction not found");
        }

        // 🔁 Prevent double refund
        const alreadyRefunded = await WalletLedgerModel.findOne({
            referenceTransactionID: originalTransactionID,
            type: "CREDIT",
        });

        if (alreadyRefunded) {
            throw new Error("Transaction already refunded");
        }

        const refundTransactionID = crypto.randomUUID();

        // 💸 Refund = CREDIT
        return WalletService.transact(
            walletID,
            userID,
            null, // PIN not required
            "CREDIT",
            amount,
            refundTransactionID,
        );
    }
}
