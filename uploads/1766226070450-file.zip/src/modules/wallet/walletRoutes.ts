import { Router } from "express";
import { WalletController } from "./walletController";
import { AuthMiddleware } from "../../middlewares/AuthMiddleware";

// All routes require authentication
const router = Router();
const controller = new WalletController();


/**
 * @swagger
 * /api/wallets:
 *   get:
 *     summary: Get Wallet
 *     tags: [Wallet Apis]
 *     responses:
 *       201:
 *         description: Get Wallet success
 */
router.get("/", AuthMiddleware.verify, controller.getWallet);

/**
 * @swagger
 * /api/wallets/ledger:
 *   get:
 *     summary: Get Wallet Ledger
 *     tags: [Wallet Apis]
 *     responses:
 *       201:
 *         description: Get Wallet Ledger success
 */
router.get("/ledger", AuthMiddleware.verify, controller.getLedger);

export default router;




