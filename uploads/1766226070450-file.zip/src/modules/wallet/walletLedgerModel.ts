import { Schema, model, Document } from "mongoose";

export type WalletLedgerType = "CREDIT" | "DEBIT";

export interface IWalletLedger {
  walletID: string;
  userID: string;
  type: WalletLedgerType;
  amount: number;
  opening: number;
  closing: number;
  status: "SUCCESS" | "FAILED";
  transactionID: string;
  date: Date;
}

export interface WalletLedgerDocument extends IWalletLedger, Document {}

const walletLedgerSchema = new Schema<WalletLedgerDocument>(
  {
    walletID: { type: String, required: true },
    userID: { type: String, required: true },
    type: { type: String, enum: ["CREDIT", "DEBIT"], required: true },
    amount: { type: Number, required: true },
    opening: { type: Number, required: true },
    closing: { type: Number, required: true },
    status: { type: String, enum: ["SUCCESS", "FAILED"], required: true },
    transactionID: { type: String, required: true, unique: true },
    date: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export const WalletLedgerModel = model<WalletLedgerDocument>(
  "WalletLedger",
  walletLedgerSchema
);
