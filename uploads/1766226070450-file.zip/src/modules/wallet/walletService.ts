// import mongoose from "mongoose";
// import crypto from "crypto";
// import { WalletModel } from "./walletModel";
// import { WalletLedgerModel } from "./walletLedgerModel";

// export class WalletService {
//   static async transact(
//     walletID: string,
//     userID: string,
//     pin: string | null,
//     type: "DEBIT" | "CREDIT",
//     amount: number,
//     transactionID = crypto.randomUUID()
//   ) {
//     if (amount <= 0) throw new Error("Amount must be greater than zero");

//     const session = await mongoose.startSession();
//     session.startTransaction();

//     try {
//       const wallet = await WalletModel.findOne({
//         _id: walletID,
//         userID,
//         isActive: true,
//       }).session(session);

//       if (!wallet) throw new Error("Wallet not found or inactive");

//       if (type === "DEBIT") {
//         if (!pin) throw new Error("PIN required for debit");
//         const isValid = await wallet.verifyPin(pin);
//         if (!isValid) throw new Error("Invalid wallet PIN");
//       }

//       // Idempotency check
//       const existing = await WalletLedgerModel.findOne({ transactionID }).session(session);
//       if (existing) {
//         await session.commitTransaction();
//         return existing;
//       }

//       const opening = wallet.balance;
//       const closing = type === "DEBIT" ? opening - amount : opening + amount;

//       if (closing < 0) throw new Error("Insufficient balance");

//       wallet.balance = closing;
//       await wallet.save({ session });

//       const [ledger] = await WalletLedgerModel.create(
//         [
//           {
//             walletID,
//             userID,
//             type,
//             amount,
//             opening,
//             closing,
//             status: "SUCCESS",
//             transactionID,
//             date: new Date(),
//           },
//         ],
//         { session }
//       );

//       await session.commitTransaction();
//       return ledger;
//     } catch (err) {
//       await session.abortTransaction();
//       throw err;
//     } finally {
//       session.endSession();
//     }
//   }
// }





import mongoose from "mongoose";
import crypto from "crypto";
import { WalletModel } from "./walletModel";
import { WalletLedgerModel } from "./walletLedgerModel";

export class WalletService {
  static async transact(
    walletID: string,
    userID: string,
    pin: string | null,
    type: "DEBIT" | "CREDIT",
    amount: number,
    transactionID = crypto.randomUUID()
  ) {
    if (amount <= 0) throw new Error("Amount must be greater than zero");

    try {
      const wallet = await WalletModel.findOne({
        _id: walletID,
        userID,
        isActive: true,
      });

      if (!wallet) throw new Error("Wallet not found or inactive");

      if (type === "DEBIT") {
        if (!pin) throw new Error("PIN required for debit");
        const isValid = await wallet.verifyPin(pin);
        if (!isValid) throw new Error("Invalid wallet PIN");
      }

      const opening = wallet.balance;
      const closing = type === "DEBIT" ? opening - amount : opening + amount;

      if (closing < 0) throw new Error("Insufficient balance");

      wallet.balance = closing;
      await wallet.save();  // Save the wallet's new balance

      const ledger = await WalletLedgerModel.create([
        {
          walletID,
          userID,
          type,
          amount,
          opening,
          closing,
          status: "SUCCESS",
          transactionID,
          date: new Date(),
        },
      ]);

      return ledger[0];
    } catch (err) {
      throw err;
    }
  }
}
