import bcrypt from "bcrypt";
import { WalletModel } from "../wallet/walletModel";

export class PinService {
  static async changePin(
    userID: string,
    oldPin: string,
    newPin: string
  ) {
    const wallet = await WalletModel.findOne({ userID });
    if (!wallet) throw new Error("Wallet not found");

    const match = await bcrypt.compare(oldPin, wallet.pinHash);
    if (!match) throw new Error("Invalid old PIN");

    wallet.pinHash = await bcrypt.hash(newPin, 10);
    await wallet.save();

    return { success: true };
  }
}
