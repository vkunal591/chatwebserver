import { Request, Response } from "express";
import { WalletQueryService } from "./walletQueryService";
import { AuthRequest } from "../../types/userType"
export class WalletController {
  getWallet = async (req: AuthRequest, res: Response) => {
    try {
      if (!req.user) throw new Error("User not authenticated");
      console.log(req.user)

      const userID = req.user.userID;
      const wallet = await WalletQueryService.getWalletByUser(userID);

      res.json({ success: true, data: wallet });
    } catch (err: any) {
      res.status(404).json({ success: false, message: err.message });
    }
  };

  getLedger = async (req: AuthRequest, res: Response) => {
    try {
      if (!req.user) throw new Error("User not authenticated");
      const userID = req.user.userID;

      const ledger = await WalletQueryService.getLedger(userID);

      res.json({ success: true, data: ledger });
    }
    catch (err: any) {
      console.log(err);

      res.status(400).json({ success: false, message: err.message });
    }
  };
}
