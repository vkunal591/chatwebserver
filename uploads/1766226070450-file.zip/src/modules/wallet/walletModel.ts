import { Schema, model, Document } from "mongoose";
import bcrypt from "bcrypt";

export interface IWallet {
  walletID: string;
  userID: string;
  balance: number;
  isActive: boolean;
  pinHash: string;
  pinAttempts: number;
  pinBlockedUntil?: Date;
}

export interface WalletDocument extends IWallet, Document {
  createdAt: Date;
  updatedAt: Date;

  setPin(pin: string): Promise<void>;
  verifyPin(pin: string): Promise<boolean>;
}

const walletSchema = new Schema<WalletDocument>(
  {
    walletID: { type: String, required: true, unique: true },
    userID: { type: String, required: true, unique: true },
    balance: { type: Number, required: true, default: 0 },
    isActive: { type: Boolean, default: true },
    pinHash: { type: String, required: true },
    pinAttempts: { type: Number, default: 0 },
    pinBlockedUntil: { type: Date },
  },
  { timestamps: true }
);


walletSchema.methods.setPin = async function (pin: string) {
  if (!/^\d{4,6}$/.test(pin)) throw new Error("PIN must be 4–6 digits");
  this.pinHash = await bcrypt.hash(pin, 10);
  this.pinAttempts = 0;
  this.pinBlockedUntil = undefined;
};

walletSchema.methods.verifyPin = async function (pin: string) {
  if (this.pinBlockedUntil && this.pinBlockedUntil > new Date()) {
    throw new Error("Wallet PIN temporarily blocked");
  }
  const match = await bcrypt.compare(pin, this.pinHash);
  if (!match) {
    this.pinAttempts += 1;
    if (this.pinAttempts >= 5) {
      this.pinBlockedUntil = new Date(Date.now() + 15 * 60 * 1000);
      this.pinAttempts = 0;
    }
    await this.save();
    return false;
  }
  this.pinAttempts = 0;
  this.pinBlockedUntil = undefined;
  await this.save();
  return true;
};

export const WalletModel = model<WalletDocument>("Wallet", walletSchema);
