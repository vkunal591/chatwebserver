import { Request, Response } from "express";
import { PaymentService } from "./paymentService";
import { AuthRequest } from "../../types/userType";

export class PaymentController {

  // ================= ADD FUNDS =================
  addFunds = async (req: AuthRequest, res: Response) => {
    try {
      if (!req.user) throw new Error("User not authenticated");

      const userID = req.user.userID;
      const { amount } = req.body;

      if (!userID || !amount) {
        return res.status(400).json({
          success: false,
          message: "userID and amount are required",
        });
      }

      const result = await PaymentService.addFunds(userID, Number(amount));

      return res.status(200).json({
        success: true,
        data: result,
      });
    } catch (err: any) {
      console.error("Add funds error:", err);
      return res.status(400).json({
        success: false,
        message: err.message,
      });
    }
  };

  // ================= VERIFY PAYMENT + 302 REDIRECT =================
  verifyPayment = async (req: AuthRequest, res: Response) => {
    try {
      /**
       * Gateways usually send:
       * - POST with x-www-form-urlencoded → req.body
       * - GET redirect → req.query
       */
      let paymentData =
        req.body && Object.keys(req.body).length > 0
          ? req.body
          : req.query;

      if (!req.user) {
        throw Error("Not a valid token")
      }
      const userID = req.user?.userID
      paymentData = { ...paymentData, userID }
      const result = await PaymentService.verifyPayment(paymentData);
      console.log(result);


      return res.redirect(
        302,
        `http://192.168.1.3:3000/payment-status?transactionID=${result.transactionID}`
      );



    } catch (err: any) {
      console.error("Payment verification error:", err);

      return res.redirect(
        302,
        `http://192.168.1.3:3000/payment-status?transactionID=Error+Happened`
      );
    }
  };

  // ================= GET TRANSACTION STATUS =================
  getTransactionStatus = async (req: AuthRequest, res: Response) => {
    try {
      if (!req.user) throw new Error("User not authenticated");

      const userID = req.user.userID;
      const { transactionID } = req.query;

      if (!transactionID) {
        return res.status(400).json({
          success: false,
          message: "transactionID is required",
        });
      }

      const result = await PaymentService.getTransactionStatus({
        transactionID: transactionID.toString(),
        userID,
      });

      return res.status(200).json({
        success: true,
        data: result.data,
        message: result.message,
      });
    } catch (err: any) {
      console.error("Get transaction status error:", err);
      return res.status(400).json({
        success: false,
        message: err.message,
      });
    }
  };
}
