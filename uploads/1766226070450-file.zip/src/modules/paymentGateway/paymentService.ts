import crypto from "crypto";
import { WalletModel } from "../wallet/walletModel";
import { WalletService } from "../wallet/walletService";
import { PaymentGatewayModel } from "./paymentGatewayModel";
import { AdminService } from "../admin/adminService";
import { User } from "../user/UserModel";

export class PaymentService {

  static async addFunds(userID: string, amount: number) {
    if (amount <= 0) {
      throw new Error("Invalid amount");
    }

    const wallet = await WalletModel.findOne({ userID });
    if (!wallet) {
      throw new Error("Wallet not found");
    }

    const user = await User.findOne({ _id: userID });
    if (!user) {
      throw new Error("User not found");
    }

    const data = await AdminService.addFund({
      amount,
      mobileNumber: user?.mobileNumber ?? "91*********",
      returnURL: "http://localhost:9000/api/payments/verify",
      username: user.userName,
    });
    console.log(data, "dddddd")
    const transactionID =
      data?.merchantTxnRefNumber;

    await PaymentGatewayModel.create({
      walletID: wallet._id.toString(),
      userID,
      amount,
      status: "PENDING",
      transactionID,
    });

    return {
      success: true,
      transactionID,
      amount: data.amount,
      redirectUrl: data?.redirectUrl,
    };
  }


  static async verifyPayment(data: any) {
    if (!data) {
      throw new Error("Payment data is required");
    }

    // Verify from admin
    const verifyResponse = await AdminService.verifyPayment(data);
    const transactionID = verifyResponse?.gatewayTxnId;

    if (!transactionID) {
      throw Error("Transaction id not found")
    }

    const payment = await PaymentGatewayModel.findOne({ transactionID, userID: data.userID });

    if (!payment) {
      throw Error("Invalid transaction")
    }


    if (!verifyResponse || verifyResponse.status !== "SUCCESS") {
      // Update payment gateway status
      payment.status = verifyResponse.status || "PENDING";
      payment.reason = verifyResponse
      payment.verifiedAt = new Date();
      await payment.save();

      return {
        success: false,
        status: verifyResponse?.status || "PENDING",
        message: "Payment not successful yet",
        transactionID
      };
    }


    // Prevent double credit
    if (payment.status === "SUCCESS") {
      return {
        success: true,
        message: "Payment already verified",
        transactionID
      };
    }


    // Update payment gateway status
    payment.status = verifyResponse.status ?? "SUCCESS";
    payment.reason = verifyResponse
    payment.verifiedAt = new Date();
    await payment.save();

    // Get wallet
    const wallet = await WalletModel.findOne({
      _id: payment.walletID,
      userID: payment.userID,
    });
    console.log(wallet)
    if (!wallet) {
      throw new Error("Wallet not found");
    }

    // Credit wallet
    await WalletService.transact(
      wallet._id.toString(),
      payment.userID,
      null,
      "CREDIT",
      payment.amount,
      transactionID
    );


    return {
      success: true,
      message: "Payment verified and wallet credited",
      transactionID,
      amount: payment.amount,
    };
  }

  // ================= TRANSACTION STATUS =================
  static async getTransactionStatus(data: any) {
    const { transactionID, userID } = data;

    if (!transactionID) {
      throw new Error("TransactionID is required");
    }

    if (!userID) {
      throw new Error("Invalid token");
    }

    const wallet = await WalletModel.findOne({ userID }, { balance: 1 });
    if (!wallet) throw new Error("Wallet not found");

    const payment = await PaymentGatewayModel.findOne({ transactionID });
    if (!payment) throw new Error("Payment record not found");

    return {
      message: "Fetch transaction data successfully",
      data: { ...payment.toObject(), ...wallet.toObject() },
    };
  }
}
