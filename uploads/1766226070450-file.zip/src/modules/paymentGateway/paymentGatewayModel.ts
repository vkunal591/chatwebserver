import mongoose, { Schema, model, Document } from "mongoose";

export type PaymentStatus = "SUCCESS" | "FAILED" | "PENDING";

export interface IPaymentGateway extends Document {
  walletID: string;
  userID: string;
  amount: number;
  status: PaymentStatus;
  transactionID: string;
  verifiedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  reason: any
}

const paymentGatewaySchema = new Schema<IPaymentGateway>(
  {
    walletID: {
      type: String,
      required: true,
      index: true,
    },

    userID: {
      type: String,
      required: true,
      index: true,
    },

    amount: {
      type: Number,
      required: true,
      min: 0,
    },
    status: {
      type: String,
      enum: ["SUCCESS", "FAILED", "PENDING"],
      default: "PENDING",
      index: true,
    },

    transactionID: {
      type: String,
      required: true,
      unique: true,
    },

    verifiedAt: {
      type: Date,
    },
    reason: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  { timestamps: true }
);

export const PaymentGatewayModel = model<IPaymentGateway>(
  "PaymentGateway",
  paymentGatewaySchema
);
