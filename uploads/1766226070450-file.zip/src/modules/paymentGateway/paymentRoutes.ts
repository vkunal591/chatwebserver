import { Router } from "express";
import { PaymentController } from "./paymentController";
import { AuthMiddleware } from "../../middlewares/AuthMiddleware";

const router = Router();
const controller = new PaymentController();

/**
 * @swagger
 * /api/payments/add-funds:
 *   post:
 *     summary: Add funds
 *     tags: [Payment Gateway Apis]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - amount
 *             properties:
 *               amount:
 *                 type: number
 *     responses:
 *       200:
 *         description: Add funds success
 */
router.post(
    "/add-funds",
    AuthMiddleware.verify,
    controller.addFunds
);

/**
 * @swagger
 * /api/payments/verify:
 *   post:
 *     summary: Verify payment callback
 *     tags: [Payment Gateway Apis]
 *     requestBody:
 *       description: Payment gateway callback payload
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *     responses:
 *       302:
 *         description: Redirect to frontend success / failure page
 */
router.post(
    "/verify",
    controller.verifyPayment
);

/**
 * @swagger
 * /api/payments/transaction-status:
 *   get:
 *     summary: Get transaction status by transactionID
 *     tags: [Payment Gateway Apis]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: transactionID
 *         schema:
 *           type: string
 *         required: true
 *         description: Transaction ID to fetch status
 *     responses:
 *       200:
 *         description: Transaction data fetched successfully
 */
router.get(
    "/transaction-status",
    AuthMiddleware.verify,
    controller.getTransactionStatus
);

export default router;
