import { Request, Response, NextFunction } from "express";
import { AuthService } from "./AuthService";
import { successResponse } from "../../core/ApiResponse";

export class AuthController {
  constructor(private service: AuthService) {}

  login = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { mobileNumber, password } = req.body;

      const result = await this.service.login({ mobileNumber, password });

      return successResponse(res, result, "Login successful");
    } catch (error) {
      next(error);
    }
  };

  getProfile = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userID = (req as any).user.userID;
      const user = await this.service.getProfile(userID);

      return successResponse(res, user, "Profile fetched successfully");
    } catch (error) {
      next(error);
    }
  };

  updatePassword = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userID = (req as any).user.userID;

      const result = await this.service.updatePassword({
        userID,
        oldPassword: req.body.oldPassword,
        newPassword: req.body.newPassword,
      });

      return successResponse(res, result, "Password updated successfully");
    } catch (error) {
      next(error);
    }
  };

  updateProfile = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userID = (req as any).user.userID;

      const user = await this.service.updateProfile({
        userID,
        updatedData: req.body,
      });

      return successResponse(res, user, "Profile updated successfully");
    } catch (error) {
      next(error);
    }
  };

  getCurrentUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userID = (req as any).user.userID;
      const user = await this.service.getCurrentUser(userID);

      return successResponse(res, user, "Current user fetched successfully");
    } catch (error) {
      next(error);
    }
  };

  deleteUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await this.service.deleteUser({
        userID: req.params.userID,
        isDeleted: req.body.isDeleted,
      });

      return successResponse(res, user, "User deleted successfully");
    } catch (error) {
      next(error);
    }
  };
}
