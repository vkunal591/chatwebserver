import { Router } from "express";
import { AuthController } from "./AuthController";
import { AuthService } from "./AuthService";
import { AuthMiddleware } from "../../middlewares/AuthMiddleware";

const router = Router();

// ✅ AuthService no longer needs User model
const authService = new AuthService();
const authController = new AuthController(authService);


/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: Login user
 *     tags: [Auth Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               mobileNumber:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       201:
 *         description: User Login
 */
router.post("/login", authController.login);
/**
 * @swagger
 * /api/auth/profile:
 *   get:
 *     summary: Get profile
 *     tags: [Auth Apis]
 *     responses:
 *       201:
 *         description: Get Profile
 */
router.get("/profile", AuthMiddleware.verify, authController.getProfile);


/**
 * @swagger
 * /api/auth/update-password:
 *   put:
 *     summary: Update Password
 *     tags: [Auth Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               oldPassword:
 *                 type: string
 *               newPassword:
 *                 type: string
 *     responses:
 *       201:
 *         description: Update Password success
 */
router.put("/update-password", AuthMiddleware.verify, authController.updatePassword);

/**
 * @swagger
 * /api/auth/update-profile:
 *   put:
 *     summary: Update Profile
 *     tags: [Auth Apis]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               userName:
 *                 type: string
 *               apiKay:
 *                 type: string
 *               ip:
 *                 type: string
 *     responses:
 *       201:
 *         description: Update Profile success
 */
router.put("/update-profile", AuthMiddleware.verify, authController.updateProfile);

/**
 * @swagger
 * /api/auth/current-user:
 *   get:
 *     summary: Get current user
 *     tags: [Auth Apis]
 *     responses:
 *       201:
 *         description: Get current user success
 */
router.get("/current-user", AuthMiddleware.verify, authController.getCurrentUser);


export default router;



