import { User, UserDocument } from "../user/UserModel";
import { ApiError } from "../../core/ApiError";
import { TokenUtil } from "../../utils/TokenUtil";

interface LoginData {
  mobileNumber: string;
  password: string;
}

interface UpdatePasswordData {
  userID: string;
  oldPassword: string;
  newPassword: string;
}

interface DeleteUser {
  userID: string;
  isDeleted: boolean;
}

interface UpdateProfileData {
  userID: string;
  updatedData: {
    userName?: string;
    apiKey?: string;
    ip?: string[];
  };
}

export class AuthService {

  generateToken(payload: any) {
    return TokenUtil.generateToken(payload);
  }

  // ✅ LOGIN
  async login(data: LoginData) {
    const user = await User.findOne({
      mobileNumber: data.mobileNumber,
      isDeleted: false,
    }).select("+password");

    if (!user) {
      throw new ApiError(401, "Invalid mobile number or password");
    }

    const isPasswordValid = await user.verifyPassword(data.password);
    if (!isPasswordValid) {
      throw new ApiError(401, "Invalid mobile number or password");
    }

    const token = this.generateToken({
      userID: user._id,
      role: user.role,
    });

    const safeUser = user.toObject();
    delete (safeUser as any).password;

    return { token, user: safeUser };
  }

  // ✅ UPDATE PASSWORD
  async updatePassword(data: UpdatePasswordData) {
    const user = await User.findById(data.userID).select("+password");

    if (!user) {
      throw new ApiError(404, "User not found");
    }

    const isOldPasswordValid = await user.verifyPassword(data.oldPassword);
    if (!isOldPasswordValid) {
      throw new ApiError(400, "Old password is incorrect");
    }

    // ❗ DO NOT hash manually
    user.password = data.newPassword;
    await user.save();

    return { message: "Password updated successfully" };
  }

  // ✅ GET PROFILE
  async getProfile(userID: string) {
    const user = await User.findById(userID).select(
      "-password -__v -isDeleted"
    );

    if (!user) {
      throw new ApiError(404, "User not found");
    }

    return user;
  }

  // ✅ UPDATE PROFILE
  async updateProfile(data: UpdateProfileData) {
    const user = await User.findByIdAndUpdate(
      data.userID,
      data.updatedData,
      { new: true }
    ).select("-password -__v -isDeleted");

    if (!user) {
      throw new ApiError(404, "User not found");
    }

    return user;
  }

  // ✅ CURRENT USER
  async getCurrentUser(userID: string) {
    const user = await User.findById(userID).select(
      "-password -__v -isDeleted"
    );

    if (!user) {
      throw new ApiError(404, "User not found");
    }

    return user;
  }

  // ✅ SOFT DELETE USER
  async deleteUser(data: DeleteUser) {
    const user = await User.findByIdAndUpdate(
      data.userID,
      { isDeleted: data.isDeleted },
      { new: true }
    ).select("-password -__v -isDeleted");

    if (!user) {
      throw new ApiError(404, "User not found");
    }

    return user;
  }
}
