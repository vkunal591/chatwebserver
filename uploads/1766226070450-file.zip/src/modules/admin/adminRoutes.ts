import { Router } from "express";
import { AdminController } from "./adminController";
import { AuthMiddleware } from "../../middlewares/AuthMiddleware";

const adminRouter = Router();

/**
 * @swagger
 * /api/admin/current-balance:
 *   get:
 *     summary: Get current balance
 *     tags: [Admin Apis]
 *     responses:
 *       201:
 *         description: Get current balance success
 */
adminRouter.get("/current-balance", AuthMiddleware.verify, AdminController.getCurrentBalance);

/**
 * @swagger
 * /api/admin/get-biller-details:
 *   get:
 *     summary: Get biller details
 *     tags: [Admin Apis]
 *     responses:
 *       201:
 *         description: Get biller details success
 */
adminRouter.get("/get-biller-details/:id", AuthMiddleware.verify, AdminController.getBillerDetails);

/**
 * @swagger
 * /api/admin/post-bill-fetch/:billPayload:
 *   post:
 *     summary: Post bill fetch
 *     tags: [Admin Apis]
 *     responses:
 *       201:
 *         description: Post bill fetch success
 */
adminRouter.post("/get-bill", AuthMiddleware.verify, AdminController.fetchBill);

export default adminRouter;