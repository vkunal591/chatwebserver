
import { Request, Response } from "express";
import { AdminService } from "./adminService";
import { ReminderService } from "../reminder/reminderService";
import { AuthRequest } from "../../types/userType";


export class AdminController {

    static async getCurrentBalance(req: Request, res: Response) {
        try {
            const data = await AdminService.getCurrentBalance();

            return res.status(200).json({
                success: true,
                data,
            });
        } catch (error: any) {
            return res.status(500).json({
                success: false,
                message: error.message,
            });
        }
    }

    static async getBillerDetails(req: AuthRequest, res: Response) {
        try {

            const userID = req.user?.userID;
            const billerId = req.params.id;
            console.log(userID)
            if (!userID) {
                return res.status(401).json({
                    success: false,
                    message: "Unauthorized: userID not found",
                });
            }

            if (!billerId) {
                return res.status(400).json({
                    success: false,
                    message: "billerId is required",
                });
            }

            // Fetch biller details
            // const data = await AdminService.getBillerDetails(billerId);
            const data: any = {
                "status": true,
                "billerInfo": {
                    "billerInfoResponse": {
                        "responseCode": "000",
                        "biller": {
                            "billerId": "SBPDCL000BHI01",
                            "billerAliasName": "SBPDCL",
                            "billerName": "South Bihar Power Distribution Company Ltd.",
                            "billerCategory": "Electricity",
                            "billerAdhoc": "false",
                            "billerCoverage": "IND-BIH",
                            "billerFetchRequiremet": "MANDATORY",
                            "billerPaymentExactness": "Exact and above",
                            "billerSupportBillValidation": "NOT_SUPPORTED",
                            "supportPendingStatus": "No",
                            "supportDeemed": "Yes",
                            "billerStatus": "ACTIVE",
                            "billerTimeout": "",
                            "billerInputParams": {
                                "paramInfo": {
                                    "paramName": "Vehicle Number",
                                    "dataType": "NUMERIC",
                                    "isOptional": "false",
                                    "minLength": "9",
                                    "maxLength": "12",
                                    "regEx": "",
                                    "visibility": "true"
                                }
                            },
                            "billerAdditionalInfo": {
                                "paramInfo": [
                                    {
                                        "paramName": "Biller Name"
                                    },
                                    {
                                        "paramName": "Consumer Name"
                                    },
                                    {
                                        "paramName": "Division"
                                    },
                                    {
                                        "paramName": "Sub-Division"
                                    },
                                    {
                                        "paramName": "Bill Month"
                                    },
                                    {
                                        "paramName": "LT_HT"
                                    },
                                    {
                                        "paramName": "Bill Type"
                                    }
                                ]
                            },
                            "billerAmountOptions": "BASE_BILL_AMOUNT,,,",
                            "billerPaymentModes": {
                                "paymentModeInfo": [
                                    {
                                        "paymentMode": "AEPS",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Account Transfer",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Cash",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Credit Card",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Debit Card",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Internet Banking",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Prepaid Card",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "UPI",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentMode": "Wallet",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    }
                                ]
                            },
                            "billerDescription": "",
                            "rechargeAmountInValidationRequest": "",
                            "billerPaymentChannels": {
                                "paymentChannelInfo": [
                                    {
                                        "paymentChannelName": "ATM",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "AGT",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "BNKBRNCH",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "BSC",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "INT",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "INTB",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "KIOSK",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "MPOS",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "MOB",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "MOBB",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    },
                                    {
                                        "paymentChannelName": "POS",
                                        "minAmount": "10000",
                                        "maxAmount": "500000000"
                                    }
                                ]
                            },
                            "billerAdditionalInfoPayment": "",
                            "planAdditionalInfo": "",
                            "planMdmRequirement": "NOT_SUPPORTED",
                            "billerResponseType": "SINGLE",
                            "billerPlanResponseParams": "",
                            "interchangeFeeCCF1": {
                                "feeCode": "CCF1",
                                "feeDirection": "C2B",
                                "flatFee": "0",
                                "percentFee": "0.00",
                                "feeMinAmt": "0",
                                "feeMaxAmt": "999999999"
                            }
                        }
                    }
                },
                "message": "billerInfo Fetched Success",
                "error": false
            }

            // Fetch reminders
            const reminderService = new ReminderService();
            const reminders = await reminderService.getReminders(userID, billerId);

            return res.status(200).json({
                success: true,
                data: data ?? {},
                reminders,
            });

        } catch (error: any) {
            console.error(error);
            return res.status(500).json({
                success: false,
                message: error.message || "Internal server error",
            });
        }
    }


    static async fetchBill(req: AuthRequest, res: Response) {
        try {

            if (!req.user) {
                throw Error("Not valid token")
            }


            if (!req.body?.parameters) {
                throw Error("Not valid data")
            }

            const payload = req.body;
            const userID = req.user?.userID

            if (!payload) {
                return res.status(400).json({
                    success: false,
                    message: "Payload is required",
                });
            }

            const data = await AdminService.postBillFetch(payload);


            // Safely extract nested values using optional chaining
            const status = data?.status;
            const responseCode = data?.response?.billFetchResponse?.responseCode;
            const billerId = req.body?.billerId ?? "";
            const requestID = data?.requestId ?? "";

            if (status && responseCode === "000") {
                const reminderService = new ReminderService();
                await reminderService.reminderApi(
                    payload?.parameters,
                    payload,
                    billerId,
                    userID,
                    requestID
                );
            }

            return res.status(200).json({
                success: true,
                data: data ?? {},
            });

        } catch (error: any) {
            return res.status(500).json({
                success: false,
                message: error.message,
            });
        }
    }

}
