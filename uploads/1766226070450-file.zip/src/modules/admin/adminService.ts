// import axios from "axios"


// export class adminService {
//     async CurrentBalance() {
//       const result=await axios.get(`http://192.168.1.59:11789/get-current-balance?apiKey=${12}`);
//       console.log(result);
//       return result;

//     }
//       async BillerDetails() {
//       const result=await axios.get(`http://192.168.1.59:11789/get-biller-details`);
//       console.log(result);
//       return result;
//     }

//      async BillFetch() {
//       const result=await axios.get(`http://192.168.1.59:11789/post-bill-fetch`);
//       console.log(result);
//       return result;

//     }

// }




import axios, { AxiosRequestConfig } from "axios";
import { apiEndpoints } from "../../config/apiConfig";

export class AdminService {
    static async callApi(endpointName: string, params: any = {}, body: any = {}) {
        const endpoint = apiEndpoints.find(e => e.name === endpointName);
        // console.log(params,"dd")
        if (!endpoint) {
            throw new Error(`API "${endpointName}" not configured`);
        }

        const config: AxiosRequestConfig = {
            method: endpoint.method,
            url: endpoint.url,
            params: {
                ...params,
                apiKey: endpoint.apiKey,
            },
            data: body
        };

        try {

            const response = await axios(config);
            console.log(response.data,"DFDF")
            return response.data;
        } catch (error: any) {
            console.log(error.response.data)
            throw new Error("Something went to wrong");
            // throw new Error(error.response?.data?.message || error.message);
        }
    }

    static getCurrentBalance() {
        return this.callApi("currentBalance");
    }
    static getBillerDetails(billerPayload: any) {
        return this.callApi("getBillerDetails", { billerId: billerPayload });
    }

    static postBillFetch(billPayload: any) {
        return this.callApi("postBillFetch", {}, billPayload);
    }
    static addFund(billPayload: any) {
        return this.callApi("addFund", {}, billPayload);
    }
    static verifyPayment(paymentPayload: any) {
        return this.callApi("verify", {}, paymentPayload);
    }
}